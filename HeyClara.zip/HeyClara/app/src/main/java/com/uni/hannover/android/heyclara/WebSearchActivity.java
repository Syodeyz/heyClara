package com.uni.hannover.android.heyclara;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class WebSearchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_search);
    }
}